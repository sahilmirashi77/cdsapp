class Utils
{
    fun getPdfUrl():String{
        return "https://drive.google.com/file/d/1pWzIDuekL3w6ZOqCbNpIkXXc0WuBHH6O/view?usp=drivesdk" +
                "https://drive.google.com/viewerng/viewer?embedded=true&url="
}
}