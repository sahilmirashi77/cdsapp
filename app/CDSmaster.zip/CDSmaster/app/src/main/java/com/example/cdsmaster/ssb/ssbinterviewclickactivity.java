package com.example.cdsmaster.ssb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.cdsmaster.R;

public class ssbinterviewclickactivity extends AppCompatActivity {

    Button tip1,tip2,tip3,tip4,faq2,faq3,faq4;
    TextView ans1,ans2,ans3,ans4,ans5,ans6,ans7;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ssbinterviewclickactivity);

        tip1=findViewById(R.id.tipone);
        tip2=findViewById(R.id.tiptwo);
        tip3=findViewById(R.id.tipthree);
        tip4=findViewById(R.id.tipfour);
        faq2=findViewById(R.id.faqtwo);
        faq3=findViewById(R.id.faqthree);
        faq4=findViewById(R.id.faqfour);

        ans1=findViewById(R.id.interviewtextone);
        ans2=findViewById(R.id.interviewtexttwo);
        ans3=findViewById(R.id.interviewtextthree);
        ans4=findViewById(R.id.interviewtextfour);
        ans5=findViewById(R.id.textfaqtwo);
        ans6=findViewById(R.id.textfaqthree);
        ans7=findViewById(R.id.textfaqfour);



        tip1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ans1.setText(getString(R.string.ssbappearence));
            }
        });

        tip2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ans2.setText(R.string.dosandonts);
            }
        });

        tip3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ans3.setText(Html.fromHtml(getString(R.string.html)));

            }
        });

        tip4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ans4.setText(Html.fromHtml(getString(R.string.frequentquestion1)));
            }
        });

        faq2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ans5.setText(Html.fromHtml(getString(R.string.faq2)));
            }

        });

        faq3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ans6.setText(Html.fromHtml(getString(R.string.faq3)));
            }
        });

        faq4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ans7.setText(Html.fromHtml(getString(R.string.faq4)));
            }
        });
    }

}
