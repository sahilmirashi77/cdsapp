package com.example.cdsmaster;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class profileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
    }
}
