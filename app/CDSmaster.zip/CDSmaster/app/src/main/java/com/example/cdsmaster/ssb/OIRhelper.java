package com.example.cdsmaster.ssb;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

 class OIRhelper extends SQLiteOpenHelper {

    private Context context;
    private  static final String DB_NAME="OIR.db";

    private static final int DB_VERSION=5;

    private static final String TABLE_NAME ="OIR";

     private static final String UID ="_UID";

    private static final String QUESTION = "QUESTION";

    private static final String OPTA =" OPTA";

    private static final String OPTB =" OPTB";

    private static final String OPTC =" OPTC";

    private static final String OPTD =" OTPD";

    private static final String ANSWER = "ANSWER";

    private static final String CREATE_TABLE = "CREATE TABLE "+ TABLE_NAME +" ( " + UID + " INTEGER PRIMARY KEY AUTOINCREMENT ," + QUESTION +" VARCHAR(255), " + OPTA +" VARCHAR(255), " + OPTB + " VARCHAR(255), " + OPTC + " VARCHAR(255), "+ OPTD +" VARCHAR, "+ ANSWER +" VARCHAR(255));";

    private static final String DROP_TABLE ="DROP TABLE IF EXISTS "+ TABLE_NAME;


     OIRhelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        this.context=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(DROP_TABLE);
        onCreate(db);
    }



    void allQuestion(){

        ArrayList<OIRQUESTION> arrayList=new ArrayList<>();

        arrayList.add(new OIRQUESTION("who is not entrepenour","sahil","elon ","ambani","riteshagrawal","sahil"));
        arrayList.add(new OIRQUESTION("who is not enr","sahil","elon ","ambani","riteshagrawal","sahil"));
        arrayList.add(new OIRQUESTION("who is repenour","sahil","elon ","ambani","riteshagrawal","sahil"));
        arrayList.add(new OIRQUESTION("who not entrepenour","sahil","elon ","ambani","riteshagrawal","sahil"));
        arrayList.add(new OIRQUESTION("who is entrepenour","sahil","elon ","ambani","riteshagrawal","sahil"));
        arrayList.add(new OIRQUESTION("who is notpenour","sahil","elon ","ambani","riteshagrawal","sahil"));
        arrayList.add(new OIRQUESTION("who is ntrepenour","sahil","elon ","ambani","riteshagrawal","sahil"));
        arrayList.add(new OIRQUESTION("whot entrepenour","sahil","elon ","ambani","riteshagrawal","sahil"));
        arrayList.add(new OIRQUESTION("ws not entrepenour","sahil","elon ","ambani","riteshagrawal","sahil"));
        arrayList.add(new OIRQUESTION("who nontrepenour","sahil","elon ","ambani","riteshagrawal","sahil"));

        this.addAllquestion(arrayList);

    }

    private void addAllquestion(ArrayList<OIRQUESTION> allQuestions) {

        SQLiteDatabase db=this.getWritableDatabase();

        db.beginTransaction();


        try{

            ContentValues values=new ContentValues();

            for (OIRQUESTION question:allQuestions){
                values.put(QUESTION,question.getQuestion());
                values.put(OPTA,question.getOpta());
                values.put(OPTB,question.getOptb());
                values.put(OPTC,question.getOptc());
                values.put(OPTD,question.getOptd());
                values.put(ANSWER,question.getAnswer());
                db.insert(TABLE_NAME,null,values);


            }
            db.setTransactionSuccessful();
        }finally {
            db.endTransaction();
            db.close();
        }



    }


    List<OIRQUESTION> getALLofTheQuestion(){

        List<OIRQUESTION> oirquestionList=new ArrayList<>();

        SQLiteDatabase db=this.getWritableDatabase();
        db.beginTransaction();

        String coloumn[] = {UID,QUESTION,OPTA,OPTB,OPTC,OPTD,ANSWER};
        Cursor cursor=db.query(TABLE_NAME,coloumn,null,null,null,null,null);

        while (cursor.moveToNext()){
            OIRQUESTION question=new OIRQUESTION();
            question.setId(cursor.getInt(0));
            question.setQuestion(cursor.getString(1));
            question.setOpta(cursor.getString(2));
            question.setOptb(cursor.getString(3));
            question.setOptc(cursor.getString(4));
            question.setOptd(cursor.getString(5));
            question.setAnswer(cursor.getString(6));
            oirquestionList.add(question);



        }

        db.setTransactionSuccessful();
        db.endTransaction();
        cursor.close();
        db.close();
        return oirquestionList;
    }

}
